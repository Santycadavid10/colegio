using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ColegioSantaMuestra.Data;


namespace ColegioSantaMuestra.ConTrollers
{
    public class GruposController : Controller
    {
        public readonly BaseContext _context;

        public GruposController(BaseContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(){
            return View(await _context.Grupos.ToListAsync());
        }
    }
}