﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.


function cardClick(cardId) {
    // Aquí puedes hacer lo que quieras cuando se haga clic en la card
    alert("Se hizo clic en la card con ID: " + cardId);
    // Por ejemplo, podrías redirigir a una página específica usando JavaScript:
    // window.location.href = '/Controlador/Acción?id=' + cardId;

    window.location.href = '/Grupos' ;
}