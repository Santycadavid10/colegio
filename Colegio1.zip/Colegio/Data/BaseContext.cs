using Microsoft.EntityFrameworkCore;
using ColegioSantaMuestra.Models;



namespace ColegioSantaMuestra.Data
{
  public class BaseContext : DbContext
  {
    public BaseContext(DbContextOptions<BaseContext> options) : base(options)
    {
    }
    public DbSet<Grupo> Grupos { get; set; }
  }
}