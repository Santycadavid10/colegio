namespace ColegioSantaMuestra.Models
{
  public class Grupo
  {
    public int Id { get; set; }
    public string? Nombre { get; set; }
  }
}